package org.medicine.service.impl;

import java.util.List;

import org.medicine.dao.DoctorDao;
import org.medicine.entity.doctor;
import org.medicine.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class DoctorImpl implements DoctorService{
	
	@Autowired
	private DoctorDao dd;
	
	@Override
	public int lytj(doctor doctor) {
		// TODO Auto-generated method stub
		return dd.lytj(doctor);
	}

	@Override
	public List ckly(int panel_id) {
		// TODO Auto-generated method stub
		return dd.ckly(panel_id);
	}

	@Override
	public doctor tjyp(int id) {
		// TODO Auto-generated method stub
		return dd.tjyp(id);
	}

	@Override
	public List ckss(doctor doctor) {
		// TODO Auto-generated method stub
		return dd.ckss(doctor);
	}

	@Override
	public int scly(int id) {
		// TODO Auto-generated method stub
		return dd.scly(id);
	}

	

	

}
