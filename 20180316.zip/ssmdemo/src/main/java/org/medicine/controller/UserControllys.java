package org.medicine.controller;

import java.util.*;

import javax.mail.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import org.medicine.entity.doctor;
import org.medicine.entity.merdrug;
import org.medicine.entity.panel;
import org.medicine.service.DoctorService;
import org.medicine.service.MerdrugService;
import org.medicine.service.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

import org.apache.catalina.User;

/**
 * 
 * @author pengfei.liu 管理员的controller
 *
 */
@Controller
@RequestMapping("/user/")
public class UserControllys {
	@Autowired
	private UserServices us;
	
	@Autowired
	private MerdrugService ms;
	
	@Autowired
	private DoctorService ds;
	

	/**
	 * 登录 如果失败 返回页面 并且 弹出框
	 * 
	 */
	@ResponseBody
	@RequestMapping("login")
	public String login(String requestDate, HttpServletRequest request, HttpSession sessions) {
		//
		Map map = new HashMap();
		//
		JSONObject requestJson = JSONObject.fromObject(requestDate);
		System.out.println(requestJson);
		map.put("name", requestJson.getString("name"));
		map.put("password", requestJson.getString("password"));
		panel pa = us.login(map);
		sessions.setAttribute("pa", pa);
		HttpSession session = request.getSession();
		if (pa != null) {
			Map reMap = new HashMap();
			String sf = pa.getShenfen();
			reMap.put("succ", "user/logJump.do");// 这里写 跳转地址
			JSONObject jsonObject = JSONObject.fromObject(reMap);
			return jsonObject.toString();

		} else {
			Map reMap = new HashMap();
			reMap.put("succ", "false");
			JSONObject jsonObject = JSONObject.fromObject(reMap);
			return jsonObject.toString();
		}
	}

	/**
	 * 注册
	 */
	@ResponseBody
	@RequestMapping("zhuce")
	public String zhuce(String requestDate, HttpServletRequest request) {
		Map map = new HashMap();
		JSONObject requestJson = JSONObject.fromObject(requestDate);
		System.out.println(requestJson);
		map.put("name", requestJson.getString("name"));
		map.put("password", requestJson.getString("password"));
		map.put("shenfen", requestJson.getString("code"));

		String cod = requestJson.getString("code");
		if (cod.equals("2")) {
			map.put("t1", requestJson.getString("t1"));
			map.put("t2", requestJson.getString("t2"));
			map.put("t3", requestJson.getString("t3"));
			int b = us.yszhuece(map);
			if (b == 1) {
				Map reMap = new HashMap();
				reMap.put("succ", "true");
				JSONObject jsonObject = JSONObject.fromObject(reMap);
				return jsonObject.toString();
			} else {
				Map reMap = new HashMap();
				reMap.put("succ", "注册失败!");
				JSONObject jsonObject = JSONObject.fromObject(reMap);
				return jsonObject.toString();
			}
		} else {
			// 如果不是2直接 插入
			int a = us.ptzhuce(map);
			System.out.println(a);
			if (a == 1) {
				Map reMap = new HashMap();
				reMap.put("succ", "true");
				JSONObject jsonObject = JSONObject.fromObject(reMap);
				return jsonObject.toString();
			} else {
				Map reMap = new HashMap();
				reMap.put("succ", "注册失败!");
				JSONObject jsonObject = JSONObject.fromObject(reMap);
				return jsonObject.toString();
			}
		}
	}

	/**
	 * 登录跳转 分等级
	 * 
	 */
	@RequestMapping("logJump")
	public String logJump(HttpServletRequest request, HttpSession session) {
		panel pa = new panel();
		pa = (panel) session.getAttribute("pa");
		String sf = pa.getShenfen();
		System.out.println(sf);
		if (sf.equals("0")) {
			// 模块管理
			return "redirect:ckss.do";
		} else if (sf.equals("1")) {
			//
			return "shangjia/index";
		} else if (sf.equals("2")) {
			return "redirect:ckly.do";
		} else if (sf.equals("3")) {
			return "redirect:tzyw.do";
		}
		return "index";
	}

	// 返回登录页面
	@RequestMapping("tc")
	public String tc(HttpSession session) {
		session.removeAttribute("pa");
		return "login";
	}

	// 跳转留言管理
	@RequestMapping("ckss")
	public String ckss(HttpServletRequest request,doctor doctor) {
		List lylist=ds.ckss(doctor);
		System.out.println(lylist);
		request.setAttribute("lylist", lylist);
		return "guanli/liuyan";
	}
	
	//删除留言
	@RequestMapping("scly")
	public String scly(int id) {
		System.out.println(id);
		ds.scly(id);
		return "redirect:ckss.do";
	}
	
	//药品管理
	@RequestMapping("ypgl")
	public String ypgl(HttpServletRequest request,merdrug merdrug) {
		List   yplist=ms.ypgl(merdrug);
		request.setAttribute("yplist", yplist);
		return  "guanli/yaopin";
		
	}
	//上下架操作
	@RequestMapping("sjyp")
	public String sjyp(int id,HttpServletRequest request) {
		System.out.println(id);
		ms.scyp(id);
		merdrug merdrug=new merdrug();
		List   yplist=ms.ypgl(merdrug);
		request.setAttribute("yplist", yplist);
		return  "guanli/yaopin";

		
	}

	// 跳转角色管理
	@RequestMapping("tzjs")
	public String tzjs() {
		return "guanli/juese";
	}

	// 跳转审核管理
	@RequestMapping("tzsh")
	public String tzsh() {
		return "guanli/shenhe";
	}

	// 跳转信息管理
	@RequestMapping("tzxx")
	public String tzxx() {
		return "guanli/shenhe";
	}

	
	// 跳转药物选购
	@RequestMapping("tzyw")
	public String tzyw(HttpServletRequest request,merdrug merdrug) {
		System.out.println(merdrug);
		String shenhe="1";
		List ywlist=ms.findmd(shenhe);
		request.setAttribute("ywlist", ywlist);
		System.out.println(ywlist);
		return "jumin/index";
	}
	//跳转到购买页面
	@RequestMapping("gmyw")
	public String gmyw(HttpServletRequest request,int id) {
		merdrug gm=ms.gmyw(id);
		request.setAttribute("gm", gm);
		System.out.println(gm);
		return "jumin/gmyp";
	}
	// 跳转咨询医师
	@RequestMapping("tzzx")
	public String tzzx(HttpServletRequest request) {
		List yslist =us.cxys(2);
		request.setAttribute("yslist", yslist);
		System.out.println(yslist);
		return "jumin/zixun";
	}
	
	//医师留言界面
	@RequestMapping("ysly")
	public String  ysly(int id,HttpServletRequest request,HttpSession session) {
		//跳转之后获取当前登录的居民姓名,因为留言之后医师需要查看是哪位居民留言
		panel pa = new panel();
		pa = (panel) session.getAttribute("pa");
		String sf = pa.getName();
		System.out.println("当前提交人:++++++++"+sf);
		panel ysly=us.ysly(id);
		request.setAttribute("ysly",ysly );
		request.setAttribute("sf", sf);
		System.out.println(ysly);
		return "jumin/ysly";
	}
	
	//留言提交
	@RequestMapping("lytj")
	public String lytj(doctor doctor,HttpSession session,HttpServletRequest request) {
		System.out.println(doctor);
		doctor.toString();
		System.out.println(doctor.toString());
		ds.lytj(doctor);
		//tz咨询医师数据
		List yslist =us.cxys(2);
		request.setAttribute("yslist", yslist);
		return "jumin/zixun";
	}
	
	//跳转医师查看留言
	@RequestMapping("ckly")
	public String ckly(HttpServletRequest request,HttpSession session) {
		panel pa = new panel();
		pa = (panel) session.getAttribute("pa");
		int panel_id=pa.getId();
		System.out.println("取到当前登录医师编号"+panel_id);
		List lylist=ds.ckly(panel_id);
		System.out.println("根据id查到医师下的留言"+lylist);
		request.setAttribute("lylist", lylist);
		return "yishi/index";
		
	}	
	
	//跳转推荐药品
	@RequestMapping("tjyp")
	public String tjyp(int id,HttpServletRequest request) {
		//留言编号 查询 
		doctor dc=ds.tjyp(id);
		System.out.println(dc);
		request.setAttribute("dc", dc);
		//药品列表
		merdrug merdrug=new merdrug();
		String shenhe="1";
		List ywlist=ms.findmd(shenhe);
		System.out.println(ywlist);
		request.setAttribute("ywlist", ywlist);
		return "yishi/yptj";
	}
	
	
}
