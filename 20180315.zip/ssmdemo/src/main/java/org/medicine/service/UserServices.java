package org.medicine.service;

import java.util.Map;

import org.medicine.entity.panel;

public interface UserServices {
	public panel login(Map map);
	public int ptzhuce(Map map);
	public int yszhuece(Map map);
}
