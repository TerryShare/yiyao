package org.medicine.entity;

public class merdrug {
	private int id;
	private int sjid;
	private int flid;
	private String name;
	private String price;
	private int number;
	private String shangjia;
	private String img;
	private String shenhe;
	private String t1;
	private String t2;
	private String t3;
	private String t4;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSjid() {
		return sjid;
	}
	public void setSjid(int sjid) {
		this.sjid = sjid;
	}
	public int getFlid() {
		return flid;
	}
	public void setFlid(int flid) {
		this.flid = flid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getShangjia() {
		return shangjia;
	}
	public void setShangjia(String shangjia) {
		this.shangjia = shangjia;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getShenhe() {
		return shenhe;
	}
	public void setShenhe(String shenhe) {
		this.shenhe = shenhe;
	}
	public String getT1() {
		return t1;
	}
	public void setT1(String t1) {
		this.t1 = t1;
	}
	public String getT2() {
		return t2;
	}
	public void setT2(String t2) {
		this.t2 = t2;
	}
	public String getT3() {
		return t3;
	}
	public void setT3(String t3) {
		this.t3 = t3;
	}
	public String getT4() {
		return t4;
	}
	public void setT4(String t4) {
		this.t4 = t4;
	}
	@Override
	public String toString() {
		return "merdrug [id=" + id + ", sjid=" + sjid + ", flid=" + flid + ", name=" + name + ", price=" + price
				+ ", number=" + number + ", shangjia=" + shangjia + ", img=" + img + ", shenhe=" + shenhe + ", t1=" + t1
				+ ", t2=" + t2 + ", t3=" + t3 + ", t4=" + t4 + "]";
	}
	
	
}
