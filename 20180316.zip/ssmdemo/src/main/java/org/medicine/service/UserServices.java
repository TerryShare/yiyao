package org.medicine.service;

import java.util.List;
import java.util.Map;

import org.medicine.entity.panel;

public interface UserServices {
	public panel login(Map map);
	public int ptzhuce(Map map);
	public int yszhuece(Map map);
	//查询现有医师
	public  List cxys(int shenfen);
	//根据id查医师
	public panel ysly(int id);
}
